﻿namespace Titanium.Web.Proxy.Http
{
    public enum TunnelType
    {
        Unknown,
        Https,
        Websocket,
        Http2,
    }
}
