﻿using System;
using System.Text;

namespace Titanium.Web.Proxy.Examples.Basic
{
    public class SampleClientState
    {
        public StringBuilder PipelineInfo { get; } = new StringBuilder();
    }
}
